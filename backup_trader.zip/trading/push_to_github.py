"""Автоотправка CSV в GitHub каждые 5 минут."""

import os
import time
import subprocess
from datetime import datetime

WORK_DIR = r"C:\trading"
LOG_FILE = os.path.join(WORK_DIR, "push_github.log")
os.chdir(WORK_DIR)

PUSH_INTERVAL_MIN = 5


def log(msg):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def git(cmd):
    try:
        result = subprocess.run(
            ["git"] + cmd,
            cwd=WORK_DIR,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.returncode, result.stdout, result.stderr
    except Exception as e:
        return -1, "", str(e)


def main():
    log("=" * 60)
    log("PUSH-TO-GITHUB стартовал")
    log("=" * 60)

    while True:
        try:
            code, out, _ = git(["status", "--porcelain"])

            if out.strip():
                git(["add", "news_sentiment.csv", "news_telegram_sentiment.csv", "rvi_data.csv"])
                git(["commit", "-m", f"auto: sync CSV {datetime.now().strftime('%H:%M')}"])
                code, out, err = git(["push"])

                if code == 0:
                    log("OK - push выполнен")
                else:
                    log(f"ОШИБКА push: {err.strip()}")
            else:
                log("Нет изменений")

        except Exception as e:
            log(f"ОШИБКА: {e}")

        time.sleep(PUSH_INTERVAL_MIN * 60)


if __name__ == "__main__":
    main()