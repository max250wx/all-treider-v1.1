"""Патч main.py: убрать дубликат _EXTRA_TICKERS, перенести mount('/') в конец."""
import io, re, shutil, sys
from datetime import datetime

PATH = r"C:\ai-trader-web\backend\main.py"
src = io.open(PATH, encoding="utf-8").read()

# бэкап
bak = PATH + ".bak_" + datetime.now().strftime("%Y%m%d_%H%M%S")
shutil.copy(PATH, bak)
print("бэкап:", bak)

# ── 1. Убрать дубликат блока _EXTRA_TICKERS ──
marker = "# --- расширение списка для тестирования ---"
parts = src.split(marker)
if len(parts) >= 3:
    # оставляем только первый блок
    src = parts[0] + marker + parts[1]
    print(f"удалён дубликат: было {len(parts) - 1} блоков, стало 1")
else:
    print("дубликат не найден — пропуск")

# ── 2. Вырезать mount('/') из текущего места ──
mount_re = re.compile(
    r'^app\.mount\("/", StaticFiles\([^\)]*\)[^\n]*\n',
    re.M,
)
matches = mount_re.findall(src)
if matches:
    src = mount_re.sub("", src)
    print(f"вырезано mount-строк: {len(matches)}")

# ── 3. Убрать двойной mount('/static') внутри if FRONTEND_DIR ──
# (оставляем один — тот, что в конце)
src = src.replace(
    'app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")',
    '# app.mount("/static", ...) удалён: см. mount("/") в конце файла'
)

# ── 4. Добавить mount('/') в самый конец ──
src = src.rstrip() + '''

# --- СТАТИКА (всегда в самом конце!) ---
from fastapi.staticfiles import StaticFiles as _SF
app.mount("/", _SF(directory=r"C:\\ai-trader-web\\frontend", html=True), name="static_root")
'''

io.open(PATH, "w", encoding="utf-8").write(src)
print("OK: main.py пропатчен")

# ── 5. Проверка синтаксиса ──
import ast
try:
    ast.parse(io.open(PATH, encoding="utf-8").read())
    print("синтаксис OK")
except SyntaxError as e:
    print(f"СИНТАКСИС-ОШИБКА: {e}")
    print("откат:", bak)
    shutil.copy(bak, PATH)
    sys.exit(1)