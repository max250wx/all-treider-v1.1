"""
Полный тест API AI Trader Web.
Проверяет все эндпоинты, все категории инструментов и граничные случаи.
"""
import json
import sys
import time
import urllib.error
import urllib.parse
import urllib.request

BASE = "http://127.0.0.1:8000"
TIMEOUT = 60

results = []  # (name, passed, info)


def hit(method, path, timeout=TIMEOUT):
    req = urllib.request.Request(BASE + path, method=method)
    t0 = time.monotonic()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            body = r.read().decode("utf-8", errors="replace")
            return r.status, body, (time.monotonic() - t0) * 1000
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        return e.code, body, (time.monotonic() - t0) * 1000
    except Exception as e:
        return 0, f"{type(e).__name__}: {e}", (time.monotonic() - t0) * 1000


def check(name, method, path, expected, validator=None):
    status, body, ms = hit(method, path)
    ok = status == expected
    info = ""
    if ok and validator:
        try:
            data = json.loads(body)
            ok, info = validator(data)
        except Exception as e:
            ok = False
            info = f"JSON parse: {e}"
    elif ok:
        info = f"{len(body)}b"
    else:
        info = body[:160].replace("\n", " ")
    results.append((name, ok, info, status, ms))
    mark = "OK " if ok else "FAIL"
    print(f"  [{mark}] {name:45s} {method:4s} {path:60s} {status} ({ms:5.0f}ms) {info}")
    return ok, body


# ---------- валидаторы ----------

def v_health(d):
    return (d.get("status") == "ok"), f"status={d.get('status')}"


def v_instruments(d):
    cats = d.get("categories") or {}
    if not cats:
        return False, "нет categories"
    total = sum(len(c.get("items", [])) for c in cats.values())
    return total > 0, f"категорий={len(cats)}, тикеров={total}"


def v_quote(d):
    if d.get("last") is None:
        return False, "нет last"
    return True, f"last={d.get('last')} chg={d.get('change_pct')}"


def v_candles(d):
    n = len(d.get("candles") or [])
    if n == 0:
        return False, "0 свечей"
    first = d["candles"][0]["time"][:16]
    last = d["candles"][-1]["time"][:16]
    return True, f"свечей={n}, {first} .. {last}"


def v_orderbook(d):
    nb = len(d.get("bids") or [])
    na = len(d.get("asks") or [])
    src = d.get("source", "?")
    return (nb > 0 or na > 0), f"bids={nb}, asks={na}, src={src}"


def v_trades(d):
    n = len(d.get("trades") or [])
    return True, f"сделок={n}"


def v_scan(d):
    total = d.get("total") or 0
    ok = d.get("ok") or 0
    failed = d.get("failed") or 0
    if total == 0:
        return False, "total=0"
    return True, f"total={total} ok={ok} failed={failed}"


def v_error(d):
    return ("detail" in d), f"detail={str(d.get('detail'))[:60]}"


# ---------- начало ----------
print()
print("=" * 130)
print("ТЕСТ API AI Trader Web")
print("=" * 130)

# --- БЛОК 1. Базовые эндпоинты ---
print("\n[1] Базовые эндпоинты")
check("health",           "GET", "/api/health",   200, v_health)
check("instruments",      "GET", "/api/instruments", 200, v_instruments)
check("root (HTML)",      "GET", "/",             200, None)

# --- БЛОК 2. Котировки по всем категориям ---
print("\n[2] Котировки: по одному тикеру из каждой категории")
status, body, _ = hit("GET", "/api/instruments")
if status == 200:
    cats = json.loads(body).get("categories") or {}
else:
    cats = {}
    print("  ! не могу получить instruments — пропускаю")

samples = {}
for cat, data in cats.items():
    items = data.get("items") or []
    if not items:
        continue
    first = items[0]
    samples[cat] = (first["ticker"], first["board"])
    path = f"/api/quote/{first['board']}/{first['ticker']}"
    check(f"quote/{cat}: {first['ticker']}", "GET", path, 200, v_quote)

# --- БЛОК 3. Свечи ---
print("\n[3] Свечи: разные таймфреймы")
if "stocks" in samples:
    t, b = samples["stocks"]
    for tf in ("M1", "M5", "M15", "H1", "D1"):
        check(f"candles {tf} ({t})", "GET", f"/api/candles/{b}/{t}?timeframe={tf}&count=20", 200, v_candles)

# --- БЛОК 4. Стакан ---
print("\n[4] Стакан: акции и фьючерсы")
if "stocks" in samples:
    t, b = samples["stocks"]
    check(f"orderbook (stocks, {t})", "GET", f"/api/orderbook/{t}", 200, v_orderbook)
if "futures" in samples:
    t, b = samples["futures"]
    check(f"orderbook (futures, {t})", "GET", f"/api/orderbook/{t}", 200, v_orderbook)

# --- БЛОК 5. Сделки ---
print("\n[5] Сделки: акции и фьючерсы")
if "stocks" in samples:
    t, b = samples["stocks"]
    check(f"trades (stocks, {t})", "GET", f"/api/trades/{t}?limit=10", 200, v_trades)
if "futures" in samples:
    t, b = samples["futures"]
    check(f"trades (futures, {t})", "GET", f"/api/trades/{t}?limit=10", 200, v_trades)

# --- БЛОК 6. Скан по категориям ---
print("\n[6] Скан по каждой категории")
for cat in cats:
    check(f"scan/{cat}", "GET", f"/api/scan?category={cat}", 200, v_scan)

# --- БЛОК 7. Граничные случаи ---
print("\n[7] Граничные случаи (ожидаем 4xx)")
check("unknown ticker",    "GET", "/api/quote/TQBR/ZZZZZZ",  404, v_error)
check("unknown board",     "GET", "/api/quote/XXXX/ZZZZZZ",  404, v_error)
check("bad timeframe",     "GET", f"/api/candles/TQBR/{samples.get('stocks',('SBER','TQBR'))[0]}?timeframe=XYZ", 400, v_error)
check("unknown trades (пустой список OK)", "GET", "/api/trades/ZZZZZZ?limit=5", 200, lambda d: (len(d.get("trades") or [])==0, "trades=0 OK"))
check("bad scan category (пусто OK)", "GET", "/api/scan?category=nosuch", 200, lambda d: ((d.get("total") or 0)==0, "total=0 OK"))

# --- итог ---
print()
print("=" * 130)
passed = sum(1 for r in results if r[1])
failed = len(results) - passed
print(f"ИТОГО: {passed} OK / {failed} FAIL из {len(results)}")
print("=" * 130)

if failed:
    print("\nПровалы:")
    for name, ok, info, status, ms in results:
        if not ok:
            print(f"  - {name}: {info}")

# сохранить отчёт
report = {
    "passed": passed, "failed": failed, "total": len(results),
    "results": [{"name": n, "ok": ok, "info": i, "status": s, "ms": round(ms, 1)} for n, ok, i, s, ms in results],
    "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
}
try:
    with open(r"C:\trading\test_report.json", "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    print("\nОтчёт сохранён: C:\\trading\\test_report.json")
except Exception as e:
    print(f"\nНе удалось сохранить отчёт: {e}")

sys.exit(0 if failed == 0 else 1)
