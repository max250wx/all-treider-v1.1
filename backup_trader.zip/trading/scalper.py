"""
scalper.py — ядро скальпинга. Читает реальные CSV от orderflow_rest.py
и rvi_collector.py, считает confluence-score, пишет сигналы в журнал.
Без реальных ордеров — только сигналы (dry-run).
"""
import csv
import os
import time
from datetime import datetime

WORK_DIR = r"C:\trading"
os.chdir(WORK_DIR)

TICKERS = ["GAZP", "RUAL"]
POLL_SEC = 5
ENTRY_SCORE = 2

STATE_FILE = "scalper_state.json"
SIGNALS_CSV = "scalper_signals.csv"


def tail_csv(path, n):
    if not os.path.exists(path):
        return [], []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        r = csv.reader(f)
        header = next(r, None)
        rows = list(r)
    return header, rows[-n:] if len(rows) > n else rows


def to_float(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def orderbook_imbalance(ticker, n=50):
    header, rows = tail_csv(f"orderbook_{ticker}.csv", n)
    if not header or not rows:
        return None
    idx = {c: i for i, c in enumerate(header)}
    bid_cols = [c for c in header if c.startswith("bid") and c.endswith("_qty")]
    ask_cols = [c for c in header if c.startswith("ask") and c.endswith("_qty")]
    last = rows[-1]
    bid = sum(to_float(last[idx[c]]) or 0 for c in bid_cols)
    ask = sum(to_float(last[idx[c]]) or 0 for c in ask_cols)
    total = bid + ask
    return (bid - ask) / total if total else 0.0


def trades_delta(ticker, n=200):
    header, rows = tail_csv(f"trades_{ticker}.csv", n)
    if not header or not rows:
        return None
    idx = {c: i for i, c in enumerate(header)}
    buy = sell = 0.0
    for r in rows:
        try:
            qty = to_float(r[idx["quantity"]]) or 0
            d = int(r[idx["direction"]])
        except (KeyError, IndexError, ValueError):
            continue
        if d == 1:
            buy += qty
        elif d == 2:
            sell += qty
    total = buy + sell
    return (buy - sell) / total if total else 0.0


def rvi_signal():
    header, rows = tail_csv("rvi_data.csv", 1)
    if not header or not rows:
        return None
    idx = {c: i for i, c in enumerate(header)}
    val = to_float(rows[-1][idx.get("rvi_current", 0)])
    if val is None:
        return None
    return (val - 50) / 50


def score(ticker):
    signals = {
        "imbalance": orderbook_imbalance(ticker),
        "delta":     trades_delta(ticker),
        "rvi":       rvi_signal(),
    }
    votes = {}
    for k, v in signals.items():
        if v is None:
            votes[k] = 0
        elif v > 0.15:
            votes[k] = 1
        elif v < -0.15:
            votes[k] = -1
        else:
            votes[k] = 0
    total = sum(votes.values())
    return total, votes, signals


def log_signal(ticker, total, votes, raw):
    header = not os.path.exists(SIGNALS_CSV)
    with open(SIGNALS_CSV, "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if header:
            w.writerow(["ts", "ticker", "score", "side",
                        "imbalance", "delta", "rvi",
                        "imb_raw", "delta_raw", "rvi_raw"])
        side = "LONG" if total >= ENTRY_SCORE else "SHORT" if total <= -ENTRY_SCORE else "-"
        w.writerow([
            datetime.now().isoformat(timespec="seconds"),
            ticker, total, side,
            votes["imbalance"], votes["delta"], votes["rvi"],
            round(raw["imbalance"] or 0, 4),
            round(raw["delta"] or 0, 4),
            round(raw["rvi"] or 0, 4),
        ])


def run():
    print(f"[scalper] старт. Тикеры: {TICKERS}, порог: |score| >= {ENTRY_SCORE}")
    last_state = {}
    try:
        while True:
            line_parts = []
            for t in TICKERS:
                total, votes, raw = score(t)
                side = "LONG" if total >= ENTRY_SCORE else "SHORT" if total <= -ENTRY_SCORE else "-"
                line_parts.append(
                    f"{t}: score={total:+d} [{side}] "
                    f"imb={raw['imbalance'] or 0:+.3f} "
                    f"dlt={raw['delta'] or 0:+.3f} "
                    f"rvi={raw['rvi'] or 0:+.3f}"
                )
                prev = last_state.get(t, "-")
                if side != prev and side != "-":
                    log_signal(t, total, votes, raw)
                    print(f"  >>> СИГНАЛ {t}: {side}")
                last_state[t] = side
            print(f"[{datetime.now():%H:%M:%S}] " + " | ".join(line_parts))
            time.sleep(POLL_SEC)
    except KeyboardInterrupt:
        print("\n[scalper] остановлен")


if __name__ == "__main__":
    run()
