"""Авторассылка (облачная версия) — читает RVI из GitHub."""

import os
import asyncio
import csv
from io import StringIO
from datetime import datetime, timezone

import requests
from aiogram import Bot
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8870582892:AAGiWiCSPt5aZvol7GWzDGMixSCvjaRywa8")
CHAT_ID = int(os.environ.get("CHAT_ID", "994444680"))
RAW_URL = "https://raw.githubusercontent.com/max250wx/-ai-trader-moex/main/"

CHECK_INTERVAL_SEC = 120
RVI_THRESHOLD = 40
COOLDOWN_MIN = 60


def fetch_csv(filename):
    try:
        r = requests.get(RAW_URL + filename, timeout=15)
        if r.status_code != 200:
            return []
        return list(csv.DictReader(StringIO(r.text)))
    except Exception:
        return []


def get_rvi():
    rows = fetch_csv("rvi_data.csv")
    if not rows:
        return None
    try:
        last = rows[-1]
        return {"value": float(last["rvi_current"]), "change": float(last["change_pct"])}
    except Exception:
        return None


async def main():
    print("Auto-notify запущен (облако)")
    bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    last_alert = None

    while True:
        rvi = get_rvi()
        now = datetime.now(timezone.utc)

        if rvi and rvi["value"] > RVI_THRESHOLD:
            should_send = last_alert is None or (now - last_alert).total_seconds() > COOLDOWN_MIN * 60
            if should_send:
                try:
                    await bot.send_message(
                        CHAT_ID,
                        f"🚨 <b>RVI алерт</b>\n\nИндекс страха: <b>{rvi['value']:.2f}</b>\nИзменение: {rvi['change']:+.2f}%\n\nПаника на рынке."
                    )
                    print(f"Алерт: RVI={rvi['value']:.2f}")
                    last_alert = now
                except Exception as e:
                    print(f"Ошибка: {e}")

        await asyncio.sleep(CHECK_INTERVAL_SEC)


if __name__ == "__main__":
    asyncio.run(main())