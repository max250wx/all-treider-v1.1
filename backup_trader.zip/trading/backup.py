import datetime
import os
import shutil
import sys
import zipfile

SRC = r"C:\ai-trader-web"
DST_DIR = r"C:\trading\backups"

# что не бэкапить
SKIP_DIRS = {"__pycache__", ".venv", "venv", "node_modules", ".git", ".idea", ".vscode"}
SKIP_EXT  = {".pyc", ".pyo", ".log"}

os.makedirs(DST_DIR, exist_ok=True)
stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
zip_path = os.path.join(DST_DIR, f"ai-trader-web_{stamp}.zip")

files_total = 0
bytes_total = 0

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
    for root, dirs, files in os.walk(SRC):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            ext = os.path.splitext(f)[1].lower()
            if ext in SKIP_EXT:
                continue
            full = os.path.join(root, f)
            rel = os.path.relpath(full, SRC)
            try:
                z.write(full, rel)
                files_total += 1
                bytes_total += os.path.getsize(full)
            except Exception as e:
                print(f"  SKIP {rel}: {e}")

size_mb = os.path.getsize(zip_path) / 1024 / 1024
print(f"Backup: {zip_path}")
print(f"  файлов: {files_total}")
print(f"  исходный объём: {bytes_total/1024/1024:.2f} MB")
print(f"  zip: {size_mb:.2f} MB")

# оставить только 10 последних бэкапов
backups = sorted(
    [os.path.join(DST_DIR, f) for f in os.listdir(DST_DIR) if f.startswith("ai-trader-web_") and f.endswith(".zip")],
    key=os.path.getmtime,
    reverse=True,
)
for old in backups[10:]:
    os.remove(old)
    print(f"  удалён старый: {os.path.basename(old)}")

print("OK")
