"""Telegram-бот (облачная версия) — читает данные из GitHub."""

import os
import csv
import asyncio
from datetime import datetime, timezone, timedelta
from io import StringIO

import requests
from aiogram import Bot, Dispatcher
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

BOT_TOKEN = os.environ.get("BOT_TOKEN", "8870582892:AAGiWiCSPt5aZvol7GWzDGMixSCvjaRywa8")
RAW_URL = "https://raw.githubusercontent.com/max250wx/-ai-trader-moex/main/"

bot = Bot(token=BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
dp = Dispatcher()


def fetch_csv(filename):
    try:
        r = requests.get(RAW_URL + filename, timeout=15)
        if r.status_code != 200:
            return []
        return list(csv.DictReader(StringIO(r.text)))
    except Exception:
        return []


def get_rvi():
    rows = fetch_csv("rvi_data.csv")
    if not rows:
        return None
    try:
        last = rows[-1]
        return {"value": float(last["rvi_current"]), "change": float(last["change_pct"])}
    except Exception:
        return None


def get_fresh_news(n=5):
    rows = fetch_csv("news_sentiment.csv")
    if not rows:
        return []
    for r in rows:
        try:
            r["_ts"] = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
        except Exception:
            r["_ts"] = datetime.min.replace(tzinfo=timezone.utc)
    rows.sort(key=lambda r: r["_ts"], reverse=True)
    cutoff = datetime.now(timezone.utc) - timedelta(hours=24)
    rows = [r for r in rows if r["_ts"] >= cutoff]
    return rows[:n]


def get_tg_news(n=5):
    rows = fetch_csv("news_telegram_sentiment.csv")
    if not rows:
        return []
    for r in rows:
        try:
            r["_ts"] = datetime.fromisoformat(r["timestamp"].replace("Z", "+00:00"))
        except Exception:
            r["_ts"] = datetime.min.replace(tzinfo=timezone.utc)
    rows.sort(key=lambda r: r["_ts"], reverse=True)
    return rows[:n]


@dp.message(Command("start"))
async def cmd_start(msg: Message):
    await msg.answer(
        "<b>AI-трейдер MOEX (облако)</b>\n\n"
        "Команды:\n"
        "/news - 5 свежих RSS-новостей\n"
        "/tg - 5 свежих из Telegram\n"
        "/rvi - индекс страха\n"
        "/status - состояние данных"
    )


@dp.message(Command("news"))
async def cmd_news(msg: Message):
    await msg.answer("Загружаю...")
    news = get_fresh_news(5)
    if not news:
        await msg.answer("Нет данных.")
        return
    lines = ["<b>RSS-новости:</b>\n"]
    for i, n in enumerate(news, 1):
        try:
            ts = n["_ts"].strftime("%H:%M")
        except Exception:
            ts = "??:??"
        sent = float(n.get("sentiment", 0))
        emoji = "🟢" if sent > 0.3 else ("🔴" if sent < -0.3 else "⚪")
        lines.append(f"{i}. {emoji} [{ts}] {n['title'][:130]}")
    await msg.answer("\n\n".join(lines))


@dp.message(Command("tg"))
async def cmd_tg(msg: Message):
    await msg.answer("Загружаю...")
    news = get_tg_news(5)
    if not news:
        await msg.answer("Нет Telegram-новостей.")
        return
    lines = ["<b>Telegram:</b>\n"]
    for i, n in enumerate(news, 1):
        try:
            ts = n["_ts"].strftime("%H:%M")
        except Exception:
            ts = "??:??"
        sent = float(n.get("sentiment", 0))
        emoji = "🟢" if sent > 0.3 else ("🔴" if sent < -0.3 else "⚪")
        text = n.get("text", "")[:130]
        lines.append(f"{i}. {emoji} [{ts}] [{n.get('channel', '?')}]\n{text}")
    await msg.answer("\n\n".join(lines))


@dp.message(Command("rvi"))
async def cmd_rvi(msg: Message):
    await msg.answer("Загружаю...")
    r = get_rvi()
    if not r:
        await msg.answer("RVI не найден.")
        return
    v, ch = r["value"], r["change"]
    if v > 60: zone = "🔴 ЭКСТРЕМАЛЬНАЯ ПАНИКА"
    elif v > 40: zone = "🟠 ПАНИКА"
    elif v < 20: zone = "🟢 СПОКОЙСТВИЕ"
    else: zone = "🟡 НЕЙТРАЛЬНО"
    arrow = "↗" if ch > 0 else ("↘" if ch < 0 else "→")
    await msg.answer(f"<b>RVI</b>\n\nЗначение: <b>{v:.2f}</b>\nИзменение: {arrow} {ch:+.2f}%\nЗона: {zone}")


@dp.message(Command("status"))
async def cmd_status(msg: Message):
    await msg.answer("Проверяю...")
    news = fetch_csv("news_sentiment.csv")
    tg = fetch_csv("news_telegram_sentiment.csv")
    rvi = fetch_csv("rvi_data.csv")
    await msg.answer(
        f"<b>Состояние (GitHub)</b>\n\n"
        f"RSS-новостей: <b>{len(news)}</b>\n"
        f"Telegram: <b>{len(tg)}</b>\n"
        f"RVI: <b>{len(rvi)}</b>"
    )


async def main():
    print("Бот запущен (облако)")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())