import io
path = r"C:\trading\test_all.py"
src = io.open(path, encoding="utf-8").read()

old1 = 'check("unknown trades",    "GET", "/api/trades/ZZZZZZ?limit=5", 404, None)  # может быть 200 с пустым списком — не критично'
new1 = 'check("unknown trades (пустой список OK)", "GET", "/api/trades/ZZZZZZ?limit=5", 200, lambda d: (len(d.get("trades") or [])==0, "trades=0 OK"))'
if old1 in src:
    src = src.replace(old1, new1)
    print("OK: поправлен unknown trades")
else:
    print("WARN: строка unknown trades не найдена как есть — ищу вариант")

old2 = 'check("bad scan category", "GET", "/api/scan?category=nosuch", 200, v_scan)'
new2 = 'check("bad scan category (пусто OK)", "GET", "/api/scan?category=nosuch", 200, lambda d: ((d.get("total") or 0)==0, "total=0 OK"))'
if old2 in src:
    src = src.replace(old2, new2)
    print("OK: поправлен bad scan category")
else:
    print("WARN: строка bad scan category не найдена как есть")

io.open(path, "w", encoding="utf-8").write(src)
