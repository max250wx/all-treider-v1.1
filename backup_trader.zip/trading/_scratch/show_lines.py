import io
path = r"C:\ai-trader-web\backend\main.py"
lines = io.open(path, encoding="utf-8").read().splitlines()
print(f"Всего строк: {len(lines)}")
print("=" * 80)
for i in range(max(0, 38), min(len(lines), 65)):
    n = i + 1
    marker = " <<<" if n in (52, 53, 54) else ""
    print(f"{n:4d}: {lines[i]}{marker}")
print("=" * 80)
