"""
Валидатор INSTRUMENTS: удаляет мёртвые бумаги, добавляет живые.
Проверяет каждую бумагу через ISS marketdata, оставляет только торгуемые.
"""
import io
import re
import requests

MAIN = r"C:\ai-trader-web\backend\main.py"


def iss_get(url, only="securities", cols=None):
    params = {"iss.meta": "off", "iss.only": only}
    if cols:
        params[only + ".columns"] = cols
    try:
        r = requests.get(url, params=params, timeout=15)
        return r.json().get(only, {})
    except Exception:
        return {}


def has_data(ticker, board):
    if board == "RFUD":
        url = f"https://iss.moex.com/iss/engines/futures/markets/forts/securities/{ticker}.json"
    else:
        market = "bonds" if board in ("TQCB", "TQOB") else "shares"
        url = f"https://iss.moex.com/iss/engines/stock/markets/{market}/boards/{board}/securities/{ticker}.json"
    try:
        r = requests.get(url, params={"iss.meta": "off", "iss.only": "marketdata"}, timeout=10)
        payload = r.json().get("marketdata", {})
        return bool(payload.get("data"))
    except Exception:
        return False


print("Ищу живые облигации TQCB (погашение >= 2027)...")
bonds = iss_get(
    "https://iss.moex.com/iss/engines/stock/markets/bonds/boards/TQCB/securities.json",
    only="securities",
    cols="SECID,SHORTNAME,MATDATE",
)
live_bonds = []
for row in bonds.get("data", []):
    if len(row) < 3:
        continue
    secid, shortname, matdate = row[0], row[1], row[2]
    if matdate and matdate >= "2027-01-01":
        if has_data(secid, "TQCB"):
            live_bonds.append({"ticker": secid, "name": shortname, "board": "TQCB"})
            print(f"  + {secid} — {shortname}")
    if len(live_bonds) >= 5:
        break

print(f"\nИщу живые фонды TQTF...")
funds = iss_get(
    "https://iss.moex.com/iss/engines/stock/markets/shares/boards/TQTF/securities.json",
    only="securities",
    cols="SECID,SHORTNAME",
)
live_funds = []
for row in funds.get("data", []):
    if len(row) < 2:
        continue
    secid, shortname = row[0], row[1]
    if has_data(secid, "TQTF"):
        live_funds.append({"ticker": secid, "name": shortname, "board": "TQTF"})
        print(f"  + {secid} — {shortname}")
    if len(live_funds) >= 5:
        break

if not live_bonds and not live_funds:
    print("\nНе нашёл ничего живого. Проверьте связь с ISS.")
    raise SystemExit(1)

src = io.open(MAIN, encoding="utf-8").read()


def render_items(items):
    return "\n".join(
        f'            {{"ticker": "{x["ticker"]}", "name": "{x["name"]}", "board": "{x["board"]}"}},'
        for x in items
    )


if live_bonds:
    new_bonds = '"bonds": {\n        "label": "Облигации",\n        "items": [\n' + render_items(live_bonds) + '\n        ],\n    },'
    src, n = re.subn(
        r'"bonds": \{\s*"label": "Облигации",\s*"items": \[.*?\]\s*\},',
        new_bonds, src, flags=re.S, count=1)
    print(f"\nbonds: заменено блоков = {n}")

if live_funds:
    new_funds = '"funds": {\n        "label": "Фонды",\n        "items": [\n' + render_items(live_funds) + '\n        ],\n    },'
    src, n = re.subn(
        r'"funds": \{\s*"label": "Фонды",\s*"items": \[.*?\]\s*\},',
        new_funds, src, flags=re.S, count=1)
    print(f"funds: заменено блоков = {n}")

io.open(MAIN, "w", encoding="utf-8").write(src)
print("\nOK: main.py обновлён")
