"""
Диагностика стрима T-Invest с автопереподключением.
Токен читается из T_INVEST_TOKEN.
"""

import logging
import os
import sys
import threading
import time

from t_tech.invest import Client
from t_tech.invest.schemas import (
    CandleInstrument,
    LastPriceInstrument,
    OrderBookInstrument,
    SubscriptionInterval,
)

FIGI = "BBG004730N88"
TIMEOUT_SEC = 25
STOP_JOIN_SEC = 3
MAX_ATTEMPTS = 10
BACKOFF_SEC = [1, 5, 15, 30, 60]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s.%(msecs)03d %(levelname)-7s %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("debug_trades")


def get_token():
    token = os.environ.get("T_INVEST_TOKEN")
    if not token:
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "token.txt")
        if os.path.exists(p):
            with open(p, encoding="utf-8") as f:
                token = f.read().strip()
    if not token or token == "СЮДА_ВСТАВЬТЕ_ТОКЕН":
        log.error("Нет токена: задайте T_INVEST_TOKEN или впишите в token.txt")
        sys.exit(1)
    return token


def _try_subscribe(name, fn):
    try:
        fn()
        log.info("OK   подписка: %s", name)
    except Exception as e:
        log.error("FAIL подписка %s: %s", name, e)


def subscribe_all(stream):
    _try_subscribe("order_book", lambda: stream.order_book.subscribe(
        [OrderBookInstrument(figi=FIGI, depth=10)]))
    _try_subscribe("trades", lambda: stream.trades.subscribe([FIGI]))
    _try_subscribe("last_price", lambda: stream.last_price.subscribe(
        [LastPriceInstrument(figi=FIGI)]))
    _try_subscribe("candles", lambda: stream.candles.subscribe(
        [CandleInstrument(figi=FIGI,
                          interval=SubscriptionInterval.SUBSCRIPTION_INTERVAL_ONE_MINUTE)]))


def stop_stream(stream):
    for name in ("stop", "close", "cancel"):
        method = getattr(stream, name, None)
        if callable(method):
            try:
                log.info("Останавливаю стрим через stream.%s()", name)
                method()
                return
            except Exception as e:
                log.debug("stream.%s() не сработал: %s", name, e)
    log.warning("Не найден метод остановки стрима")


def classify(md):
    for field in ("orderbook", "trade", "last_price", "candle",
                  "subscription_status", "ping"):
        if getattr(md, field, None) is not None:
            return field
    return "other"


def run_once(client):
    counter = {k: 0 for k in ("orderbook", "trade", "last_price", "candle",
                              "subscription_status", "ping", "other")}
    limits = {"orderbook": 2, "trade": 5, "last_price": 3, "candle": 2,
              "subscription_status": 10, "ping": 1, "other": 3}
    shown = {k: 0 for k in counter}

    stream = client.create_market_data_stream()
    subscribe_all(stream)

    def consume():
        try:
            for md in stream:
                kind = classify(md)
                counter[kind] += 1
                if shown[kind] < limits[kind]:
                    shown[kind] += 1
                    log.info("[%s] %s", kind.upper(), getattr(md, kind, md))
        except Exception:
            log.exception("Ошибка в стриме")

    t0 = time.monotonic()
    worker = threading.Thread(target=consume, name="stream-consumer", daemon=True)
    worker.start()
    worker.join(TIMEOUT_SEC)

    if worker.is_alive():
        log.info("Таймаут %ss истёк, останавливаю стрим", TIMEOUT_SEC)
        stop_stream(stream)
        worker.join(STOP_JOIN_SEC)
        if worker.is_alive():
            log.warning("Поток не завершился")

    elapsed = time.monotonic() - t0
    log.info("=" * 50)
    log.info("Счётчики за %.1f сек:", elapsed)
    for k, v in counter.items():
        log.info("  %-20s: %d", k, v)
    log.info("=" * 50)


def main():
    token = get_token()
    log.info("FIGI=%s, таймаут=%ss", FIGI, TIMEOUT_SEC)
    with Client(token) as client:
        for attempt in range(1, MAX_ATTEMPTS + 1):
            try:
                log.info("--- Попытка #%d ---", attempt)
                run_once(client)
                return
            except KeyboardInterrupt:
                log.info("Прервано пользователем")
                return
            except Exception as e:
                delay = BACKOFF_SEC[min(attempt - 1, len(BACKOFF_SEC) - 1)]
                log.warning("Стрим упал: %s. Пауза %d сек", e, delay)
                time.sleep(delay)
        log.error("Исчерпаны попытки")


if __name__ == "__main__":
    main()

