import io, re
path = r"C:\ai-trader-web\backend\main.py"
src = io.open(path, encoding="utf-8").read()

if "_funds_tqbr" in src:
    print("SKIP: уже применено")
    raise SystemExit(0)

new_funds = (
    '"funds": {\n'
    '        "label": "\u0424\u043e\u043d\u0434\u044b",\n'
    '        "items": [\n'
    '            {"ticker": "TMOS", "name": "\u0422\u0438\u043d\u044c\u043a\u043e\u0444\u0444 iMOEX", "board": "TQBR"},\n'
    '            {"ticker": "SBMX", "name": "\u0421\u0431\u0435\u0440 \u0418\u043d\u0434\u0435\u043a\u0441 \u041c\u043e\u0441\u0411\u0438\u0440\u0436\u0438", "board": "TQBR"},\n'
    '            {"ticker": "SBMM", "name": "\u0421\u0431\u0435\u0440 \u0418\u043d\u0434\u0435\u043a\u0441 \u041c\u043e\u0441\u0411\u0438\u0440\u0436\u0438", "board": "TQBR"},\n'
    '            {"ticker": "EQMX", "name": "\u0412\u0418\u041c \u041b\u0438\u043a\u0432\u0438\u0434\u043d\u043e\u0441\u0442\u044c", "board": "TQBR"},\n'
    '            {"ticker": "AKGD", "name": "\u0410\u041a \u0414\u043e\u0441\u0442\u0443\u043f\u043d\u043e\u0435 \u0437\u043e\u043b\u043e\u0442\u043e", "board": "TQBR"},\n'
    '        ],\n'
    '    },  # _funds_tqbr'
)

start_marker = '"funds": {'
start = src.find(start_marker)
if start < 0:
    print("FAIL: не нашёл funds")
    raise SystemExit(1)

tail = src[start:]
m = re.search(r'\n    "(stocks|bonds|ofz|futures)": \{', tail[len(start_marker):])
if not m:
    print("FAIL: не нашёл конец funds")
    raise SystemExit(1)

end = start + len(start_marker) + m.start()
src = src[:start] + new_funds + src[end:]
io.open(path, "w", encoding="utf-8").write(src)
print("OK: funds -> TQBR")
