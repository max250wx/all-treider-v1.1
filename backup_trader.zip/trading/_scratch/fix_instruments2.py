"""
Замена bonds/funds в INSTRUMENTS по маркерам.
Облигации: TQCB, только RU000A*, погашение >= 2027, с marketdata.
Фонды: TQTF, без has_data (вечером ISS для TQTF пусто, но днём работает).
"""
import io
import re
import requests

MAIN = r"C:\ai-trader-web\backend\main.py"


def iss_get(url, only="securities", cols=None):
    params = {"iss.meta": "off", "iss.only": only}
    if cols:
        params[only + ".columns"] = cols
    try:
        return requests.get(url, params=params, timeout=15).json().get(only, {})
    except Exception:
        return {}


def has_data(ticker, board):
    if board == "RFUD":
        url = f"https://iss.moex.com/iss/engines/futures/markets/forts/securities/{ticker}.json"
    else:
        market = "bonds" if board in ("TQCB", "TQOB") else "shares"
        url = f"https://iss.moex.com/iss/engines/stock/markets/{market}/boards/{board}/securities/{ticker}.json"
    try:
        payload = requests.get(url, params={"iss.meta": "off", "iss.only": "marketdata"}, timeout=10).json().get("marketdata", {})
        return bool(payload.get("data"))
    except Exception:
        return False


# --- облигации ---
print("Ищу живые RU000A* на TQCB (погашение >= 2027, с marketdata)...")
bonds = iss_get(
    "https://iss.moex.com/iss/engines/stock/markets/bonds/boards/TQCB/securities.json",
    only="securities",
    cols="SECID,SHORTNAME,MATDATE",
)
live_bonds = []
for row in bonds.get("data", []):
    if len(row) < 3:
        continue
    secid, shortname, matdate = row[0], row[1], row[2]
    if not secid.startswith("RU000A"):
        continue
    if not matdate or matdate < "2027-01-01":
        continue
    if has_data(secid, "TQCB"):
        live_bonds.append({"ticker": secid, "name": shortname, "board": "TQCB"})
        print(f"  + {secid} — {shortname} (до {matdate})")
    if len(live_bonds) >= 5:
        break

# --- фонды (без has_data, только фильтр по SECID) ---
print("\nБеру 5 фондов с TQTF (по алфавиту, без проверки marketdata)...")
funds = iss_get(
    "https://iss.moex.com/iss/engines/stock/markets/shares/boards/TQTF/securities.json",
    only="securities",
    cols="SECID,SHORTNAME",
)
live_funds = []
for row in funds.get("data", []):
    if len(row) < 2:
        continue
    secid, shortname = row[0], row[1]
    # обходим мусор вроде паев некоторых закрытых ПИФов
    if not secid.isalpha() or len(secid) < 3 or len(secid) > 5:
        continue
    live_funds.append({"ticker": secid, "name": shortname, "board": "TQTF"})
    print(f"  + {secid} — {shortname}")
    if len(live_funds) >= 5:
        break

if not live_bonds:
    print("\nОШИБКА: не нашёл живых RU000A* облигаций. Оставлю bonds как есть.")
if not live_funds:
    print("\nОШИБКА: не нашёл фондов. Оставлю funds как есть.")

# --- замена в main.py по маркерам ---
src = io.open(MAIN, encoding="utf-8").read()


def render_items(items):
    return "\n".join(
        f'            {{"ticker": "{x["ticker"]}", "name": "{x["name"]}", "board": "{x["board"]}"}},'
        for x in items
    )


def replace_block(src, key, label, items):
    """Заменяет блок '"key": { ... },' на новый."""
    start_marker = f'"{key}": {{'
    start = src.find(start_marker)
    if start < 0:
        print(f"  ! не нашёл маркер {start_marker}")
        return src, 0
    # найти конец блока: следующий ключ верхнего уровня "xxx": {
    tail = src[start:]
    m = re.search(r'\n    "(stocks|bonds|ofz|funds|futures)": \{', tail[len(start_marker):])
    if not m:
        print(f"  ! не нашёл конец блока для {key}")
        return src, 0
    end = start + len(start_marker) + m.start()
    block = f'''"{key}": {{
        "label": "{label}",
        "items": [
{render_items(items)}
        ],
    }}'''
    new_src = src[:start] + block + src[end:]
    return new_src, 1


if live_bonds:
    src, n1 = replace_block(src, "bonds", "Облигации", live_bonds)
    print(f"\nbonds: заменено блоков = {n1}")
if live_funds:
    src, n2 = replace_block(src, "funds", "Фонды", live_funds)
    print(f"funds: заменено блоков = {n2}")

io.open(MAIN, "w", encoding="utf-8").write(src)
print("\nOK: main.py обновлён")
