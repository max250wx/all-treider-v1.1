import io, re
path = r"C:\ai-trader-web\backend\main.py"
lines = io.open(path, encoding="utf-8").read().splitlines()
changed = 0
for i in range(len(lines) - 1):
    cur = lines[i].rstrip()
    nxt = lines[i+1].lstrip()
    if cur.endswith("}") and not cur.endswith("},") and re.match(r'"(stocks|bonds|ofz|funds|futures)":', nxt):
        lines[i] = cur + ","
        changed += 1
        print(f"  починена строка {i+1}")

io.open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")
print(f"\nВсего исправлено: {changed}")
