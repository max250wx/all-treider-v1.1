import io, re
path = r"C:\ai-trader-web\backend\main.py"
src = io.open(path, encoding="utf-8").read()

# найти битую склейку
bad = '},  # _funds_tqbr"bonds": {'
if bad in src:
    src = src.replace(bad, '},\n    "bonds": {', 1)
    io.open(path, "w", encoding="utf-8").write(src)
    print("OK: склейка починена")
else:
    # возможно, был другой вариант склейки
    m = re.search(r'# _funds_tqbr"', src)
    if m:
        src = src[:m.end()-1] + '\n    ' + src[m.end():]
        io.open(path, "w", encoding="utf-8").write(src)
        print("OK: склейка починена (вариант 2)")
    else:
        print("Битая склейка не найдена. Проверьте строки 48-56 в main.py.")
