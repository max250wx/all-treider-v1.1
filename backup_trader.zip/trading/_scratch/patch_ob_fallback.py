import io
path = r"C:\ai-trader-web\backend\main.py"
src = io.open(path, encoding="utf-8").read()

if "_ob_fallback" in src:
    print("SKIP: уже применено")
    raise SystemExit(0)

new_ob = '''@app.get("/api/orderbook/{ticker}")
def get_orderbook(ticker: str, depth: int = 8):
    t = ticker.upper()
    board = _board_for_ticker(t)
    try:
        if board == "RFUD":
            url = f"https://iss.moex.com/iss/engines/futures/markets/forts/securities/{t}.json"
        else:
            market = market_for_board(board)
            url = f"https://iss.moex.com/iss/engines/stock/markets/{market}/boards/{board}/securities/{t}.json"
        r = requests.get(url, params={"iss.meta": "off", "iss.only": "orderbook,marketdata"}, timeout=10)
        r.raise_for_status()
        j = r.json()

        ob = j.get("orderbook", {})
        cols = ob.get("columns", [])
        rows = ob.get("data", [])
        idx = {c: i for i, c in enumerate(cols)}
        bids, asks = [], []
        for row in rows:
            price = row[idx["PRICE"]] if "PRICE" in idx else None
            qty   = row[idx["QUANTITY"]] if "QUANTITY" in idx else None
            side  = row[idx["BUYSELL"]] if "BUYSELL" in idx else None
            if price is None:
                continue
            entry = {"price": float(price), "quantity": int(qty or 0)}
            s = str(side).upper()
            if s in ("B", "BUY"):
                bids.append(entry)
            elif s in ("S", "SELL"):
                asks.append(entry)

        source = "orderbook"
        if not bids and not asks:
            md = j.get("marketdata", {})
            mcols = md.get("columns", [])
            mrows = md.get("data", [])
            if mrows:
                mi = {c: i for i, c in enumerate(mcols)}
                mr = mrows[0]
                bid_p = mr[mi["BID"]] if "BID" in mi else None
                ask_p = mr[mi["OFFER"]] if "OFFER" in mi else None
                bid_q = mr[mi["BIDDEPTHT"]] if "BIDDEPTHT" in mi else None
                ask_q = mr[mi["OFFERDEPTHT"]] if "OFFERDEPTHT" in mi else None
                if bid_p is not None:
                    bids.append({"price": float(bid_p), "quantity": int(bid_q or 0)})
                if ask_p is not None:
                    asks.append({"price": float(ask_p), "quantity": int(ask_q or 0)})
                source = "marketdata (fallback, вечерняя сессия)"

        return {
            "ticker": t, "board": board,
            "bids": bids[:depth], "asks": asks[:depth],
            "source": source,
        }  # _ob_fallback
    except Exception as e:
        raise HTTPException(500, f"MOEX orderbook error: {e}")


'''

marker = '@app.get("/api/orderbook/{ticker}")'
i = src.find(marker)
if i < 0:
    print("FAIL: не нашёл orderbook в файле")
    raise SystemExit(1)
j = src.find('@app.get("/api/trades/{ticker}")', i)
if j < 0:
    j = src.find('\napp.mount(', i)
if j < 0:
    print("FAIL: не нашёл куда вставить")
    raise SystemExit(1)

src = src[:i] + new_ob + src[j:]
io.open(path, "w", encoding="utf-8").write(src)
print("OK: orderbook с fallback на marketdata")
