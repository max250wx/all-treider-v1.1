import io, re
path = r"C:\ai-trader-web\backend\main.py"
src = io.open(path, encoding="utf-8").read()

if "_unified_trades" in src:
    print("SKIP: уже применено")
    raise SystemExit(0)

new_tr = '''@app.get("/api/trades/{ticker}")
def get_trades(ticker: str, limit: int = 50):
    t = ticker.upper()
    board = _board_for_ticker(t)
    try:
        if board == "RFUD":
            url = f"https://iss.moex.com/iss/engines/futures/markets/forts/securities/{t}.json"
        else:
            market = market_for_board(board)
            url = f"https://iss.moex.com/iss/engines/stock/markets/{market}/boards/{board}/securities/{t}.json"
        r = requests.get(url, params={"iss.meta": "off", "iss.only": "trades"}, timeout=10)
        r.raise_for_status()
        payload = r.json().get("trades", {})
        cols = payload.get("columns", [])
        rows = payload.get("data", [])
        idx = {c: i for i, c in enumerate(cols)}
        trades = []
        for row in rows[-limit:]:
            side = row[idx["BUYSELL"]] if "BUYSELL" in idx else None
            trades.append({
                "time": row[idx["TRADETIME"]] if "TRADETIME" in idx else None,
                "price": row[idx["PRICE"]] if "PRICE" in idx else None,
                "quantity": row[idx["QUANTITY"]] if "QUANTITY" in idx else None,
                "side": "BUY" if str(side).upper() in ("B","BUY") else "SELL" if str(side).upper() in ("S","SELL") else side,
            })
        return {"ticker": t, "board": board, "trades": trades}  # _unified_trades
    except Exception as e:
        raise HTTPException(500, f"MOEX trades error: {e}")


'''

src = re.sub(r'@app\\.get\\("/api/trades/\\{ticker\\}"\\).*?(?=\\n@app\\.get\\(|\\napp\\.mount\\(|\\Z)', new_tr, src, flags=re.S)
io.open(path, "w", encoding="utf-8").write(src)
print("OK: trades на универсальный URL")
