import io, re
path = r"C:\ai-trader-web\backend\main.py"
lines = io.open(path, encoding="utf-8").read().splitlines()

print("Строки, где ожидается запятая после } (закрытие блока перед следующим ключом):")
print("=" * 80)
for i in range(len(lines) - 1):
    cur = lines[i].rstrip()
    nxt = lines[i+1].lstrip()
    if cur.endswith("}") and not cur.endswith("},") and re.match(r'"(stocks|bonds|ofz|funds|futures)":', nxt):
        print(f"  строка {i+1}: {lines[i]!r}   СЛЕДУЮЩАЯ: {lines[i+1]!r}   <-- нет запятой")
print("=" * 80)
