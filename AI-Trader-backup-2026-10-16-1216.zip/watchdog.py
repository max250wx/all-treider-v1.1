"""
Watchdog v3: следит за всеми процессами робота.
- orderflow_rest (сбор стакана + сделок)
- rvi_collector (индекс страха)
- news_updater (автообновление новостей)
"""

import os
import sys
import time
import subprocess
from datetime import datetime


WORK_DIR = r"C:\trading"
LOG_FILE = os.path.join(WORK_DIR, "watchdog.log")
os.chdir(WORK_DIR)

STALL_MINUTES = 5
CHECK_INTERVAL_SEC = 60


TARGETS = [
    {
        "name": "orderflow_rest",
        "script": "orderflow_rest.py",
        "files": ["orderbook_GAZP.csv", "trades_GAZP.csv",
                  "orderbook_RUAL.csv", "trades_RUAL.csv"],
    },
    {
        "name": "rvi_collector",
        "script": "rvi_collector.py",
        "files": ["rvi_data.csv"],
    },
    {
        "name": "news_updater",
        "script": "news_updater.py",
        "files": ["news_updater.log"],   # активность по логу
    },
]


def log(msg):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def get_mtime(path):
    full = os.path.join(WORK_DIR, path)
    if not os.path.exists(full):
        return 0
    return os.path.getmtime(full)


def last_activity(files):
    mtimes = [get_mtime(f) for f in files]
    return max(mtimes) if mtimes else 0


def launch(script):
    log(f"  → запуск: {script}")
    try:
        proc = subprocess.Popen(
            [sys.executable, script],
            cwd=WORK_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0),
        )
        return proc
    except Exception as e:
        log(f"  ОШИБКА запуска {script}: {e}")
        return None


def kill(proc):
    if proc is None or proc.poll() is not None:
        return
    try:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
    except Exception:
        pass


def main():
    log("=" * 70)
    log("WATCHDOG v3 стартовал")
    log("=" * 70)

    processes = {}
    for t in TARGETS:
        processes[t["name"]] = launch(t["script"])
        time.sleep(2)

    last_seen = {t["name"]: time.time() for t in TARGETS}

    try:
        while True:
            time.sleep(CHECK_INTERVAL_SEC)
            now = time.time()

            for t in TARGETS:
                name = t["name"]
                mtime = last_activity(t["files"])
                stall_sec = now - max(mtime, last_seen[name])
                stall_min = stall_sec / 60

                # news_updater обновляется раз в 15 мин, даём больше времени
                stall_limit = 10 if name == "news_updater" else STALL_MINUTES

                if stall_min >= stall_limit:
                    log(f"[!] {name}: нет активности {stall_min:.1f} мин — перезапуск")
                    kill(processes.get(name))
                    processes[name] = launch(t["script"])
                    last_seen[name] = now
                else:
                    log(f"[OK] {name}: активен {stall_min:.1f} мин назад")
                    last_seen[name] = now

    except KeyboardInterrupt:
        log("Watchdog остановлен")
        for name, proc in processes.items():
            kill(proc)


if __name__ == "__main__":
    main()