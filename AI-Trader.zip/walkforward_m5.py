"""Walk-forward EMA Cross на M5 для газа (NGU6, NGV6) и Brent."""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_csv(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={
        "open": "Open", "high": "High", "low": "Low",
        "close": "Close", "volume": "Volume",
    })
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return df[df["Volume"] > 0].sort_index()


class EMACross(Strategy):
    fast = 9
    slow = 21
    stop_pct = 0.010
    tp_pct = 0.015
    size = 500

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.fast = self.I(ema, self.data.Close, self.fast)
        self.slow = self.I(ema, self.data.Close, self.slow)

    def next(self):
        if self.position or len(self.fast) < 2:
            return
        price = self.data.Close[-1]
        if self.fast[-2] <= self.slow[-2] and self.fast[-1] > self.slow[-1]:
            self.buy(size=self.size,
                     sl=price * (1 - self.stop_pct),
                     tp=price * (1 + self.tp_pct))
        elif self.fast[-2] >= self.slow[-2] and self.fast[-1] < self.slow[-1]:
            self.sell(size=self.size,
                      sl=price * (1 + self.stop_pct),
                      tp=price * (1 - self.tp_pct))


def run(data):
    bt = Backtest(
        data, EMACross,
        cash=1_000_000,
        commission=0.0002,
        spread=0.0002,
        margin=0.1,
        exclusive_orders=True,
        trade_on_close=False,
    )
    return bt.run()


def walk_forward(data, n_windows=6):
    total = len(data)
    block_size = total // (n_windows + 1)
    out = []
    for k in range(n_windows):
        test_end = block_size * (k + 2)
        test = data.iloc[block_size * (k + 1):test_end]
        if len(test) < 300:
            break
        s = run(test)
        out.append({
            "Окно": k + 1,
            "Test": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Trades": int(s["# Trades"]),
            "PF": round(s["Profit Factor"], 3) if not pd.isna(s["Profit Factor"]) else 0,
            "Sharpe": round(s["Sharpe Ratio"], 2) if not pd.isna(s["Sharpe Ratio"]) else 0,
            "Return%": round(s["Return [%]"], 3),
            "MaxDD%": round(s["Max. Drawdown [%]"], 3),
        })
    return pd.DataFrame(out)


if __name__ == "__main__":
    for name, file in [
        ("NGU6 M5", "ngu6_m5.csv"),
        ("NGV6 M5", "ng_m5.csv"),
        ("BR M5",   "br_m5.csv"),
    ]:
        print("")
        print("=" * 95)
        print("  " + name + "  (" + file + ")")
        print("=" * 95)
        try:
            data = load_csv(file)
        except FileNotFoundError:
            print("  Файл " + file + " не найден — пропускаем")
            continue

        print("Баров: " + str(len(data)))
        print("Период: " + str(data.index[0]) + " — " + str(data.index[-1]))
        print("")

        # Полный период
        s_full = run(data)
        print("── Полный период ──")
        print(pd.DataFrame([{
            "Trades":   int(s_full["# Trades"]),
            "WinRate%": round(s_full["Win Rate [%]"], 2) if not pd.isna(s_full["Win Rate [%]"]) else 0,
            "PF":       round(s_full["Profit Factor"], 3) if not pd.isna(s_full["Profit Factor"]) else 0,
            "Sharpe":   round(s_full["Sharpe Ratio"], 2) if not pd.isna(s_full["Sharpe Ratio"]) else 0,
            "Return%":  round(s_full["Return [%]"], 3),
            "MaxDD%":   round(s_full["Max. Drawdown [%]"], 3),
        }]).to_string(index=False))
        print("")

        # Walk-forward
        res = walk_forward(data, n_windows=6)
        print("── Walk-forward ──")
        print(res.to_string(index=False))
        if not res.empty:
            wins = (res["PF"] > 1.0).sum()
            print("")
            print("Окон с PF > 1.0: " + str(wins) + " из " + str(len(res)))
            print("Средний PF: " + str(round(res["PF"].mean(), 3)))
            print("Средний Sharpe: " + str(round(res["Sharpe"].mean(), 3)))