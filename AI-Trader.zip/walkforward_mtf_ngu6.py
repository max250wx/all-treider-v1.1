"""Walk-forward MTF-стратегии на NGU6."""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_mtf(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={
        "open": "Open", "high": "High", "low": "Low",
        "close": "Close", "volume": "Volume",
    })
    return df


def atr(h, l, c, p):
    h, l, c = pd.Series(h), pd.Series(l), pd.Series(c)
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / p, adjust=False).mean()


class MTFMeanRev(Strategy):
    ema_period = 20
    atr_period = 14
    atr_entry = 2.5
    atr_stop = 1.5
    size = 500

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.ema = self.I(ema, self.data.Close, self.ema_period)
        self.atr = self.I(atr, self.data.High, self.data.Low,
                          self.data.Close, self.atr_period)
        self.d1_trend = self.data.D1Trend
        self.h4_trend = self.data.H4Trend
        self.h1_trend = self.data.H1Trend

    def next(self):
        if self.position:
            if self.position.is_long and self.data.Close[-1] >= self.ema[-1]:
                self.position.close()
            elif self.position.is_short and self.data.Close[-1] <= self.ema[-1]:
                self.position.close()
            return

        hour = self.data.index[-1].hour
        if not ((10 <= hour <= 11) or (14 <= hour <= 15)):
            return

        d1, h4, h1 = self.d1_trend[-1], self.h4_trend[-1], self.h1_trend[-1]
        allow_long = (d1 == 1 and h4 == 1 and h1 == 1)
        allow_short = (d1 == 0 and h4 == 0 and h1 == 0)
        if not (allow_long or allow_short):
            return

        if pd.isna(self.atr[-1]) or pd.isna(self.ema[-1]):
            return

        price = self.data.Close[-1]
        ema_v = self.ema[-1]
        a = self.atr[-1]

        if allow_long and price < ema_v - self.atr_entry * a:
            self.buy(size=self.size, sl=price - self.atr_stop * a, tp=ema_v)
        elif allow_short and price > ema_v + self.atr_entry * a:
            self.sell(size=self.size, sl=price + self.atr_stop * a, tp=ema_v)


def run(data, atr_entry=2.5, atr_stop=1.5):
    bt = Backtest(data, MTFMeanRev, cash=1_000_000,
                  commission=0.0002, spread=0.0002, margin=0.1,
                  exclusive_orders=True, trade_on_close=False)
    return bt.run(atr_entry=atr_entry, atr_stop=atr_stop)


def walk_forward(data, n_windows=5, atr_entry=2.5, atr_stop=1.5):
    total = len(data)
    block_size = total // (n_windows + 1)
    out = []
    for k in range(n_windows):
        test_end = block_size * (k + 2)
        test = data.iloc[block_size * (k + 1):test_end]
        if len(test) < 300:
            break
        s = run(test, atr_entry, atr_stop)
        out.append({
            "Окно": k + 1,
            "Test": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Trades": int(s["# Trades"]),
            "WinRate%": round(s["Win Rate [%]"], 2) if not pd.isna(s["Win Rate [%]"]) else 0,
            "PF": round(s["Profit Factor"], 3) if not pd.isna(s["Profit Factor"]) else 0,
            "Sharpe": round(s["Sharpe Ratio"], 2) if not pd.isna(s["Sharpe Ratio"]) else 0,
            "Return%": round(s["Return [%]"], 3),
        })
    return pd.DataFrame(out)


if __name__ == "__main__":
    data = load_mtf("ngu6_mtf.csv")
    print("Баров: " + str(len(data)))
    print("Период: " + str(data.index[0]) + " — " + str(data.index[-1]))
    print("")

    # Три набора параметров из «зелёного кластера» sensitivity grid
    for entry, stop in [(1.5, 2.0), (2.0, 1.5), (2.5, 1.5)]:
        print("=" * 95)
        print(f"  Параметры: atr_entry={entry}, atr_stop={stop}")
        print("=" * 95)

        res = walk_forward(data, n_windows=5, atr_entry=entry, atr_stop=stop)
        print(res.to_string(index=False))
        if not res.empty:
            wins = (res["PF"] > 1.0).sum()
            print("")
            print("Окон с PF > 1.0: " + str(wins) + " из " + str(len(res)))
            print("Средний PF: " + str(round(res["PF"].mean(), 3)))
            print("Средний Sharpe: " + str(round(res["Sharpe"].mean(), 3)))
        print("")