"""Walk-forward EMA + patterns на газе — проверка устойчивости."""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_csv(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={"open": "Open", "high": "High", "low": "Low",
                             "close": "Close", "volume": "Volume"})
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return df[df["Volume"] > 0].sort_index()


def bullish_engulfing(o, h, l, c):
    o, c, po, pc = pd.Series(o), pd.Series(c), pd.Series(o).shift(1), pd.Series(c).shift(1)
    return ((pc < po) & (c > o) & (o <= pc) & (c >= po)).astype(int).values


def bearish_engulfing(o, h, l, c):
    o, c, po, pc = pd.Series(o), pd.Series(c), pd.Series(o).shift(1), pd.Series(c).shift(1)
    return ((pc > po) & (c < o) & (o >= pc) & (c <= po)).astype(int).values


def hammer(o, h, l, c):
    o, h, l, c = pd.Series(o), pd.Series(h), pd.Series(l), pd.Series(c)
    body = (c - o).abs()
    lw = pd.concat([o, c], axis=1).min(axis=1) - l
    uw = h - pd.concat([o, c], axis=1).max(axis=1)
    return ((lw > 2 * body) & (uw < body) & (body > 0)).astype(int).values


def shooting_star(o, h, l, c):
    o, h, l, c = pd.Series(o), pd.Series(h), pd.Series(l), pd.Series(c)
    body = (c - o).abs()
    uw = h - pd.concat([o, c], axis=1).max(axis=1)
    lw = pd.concat([o, c], axis=1).min(axis=1) - l
    return ((uw > 2 * body) & (lw < body) & (body > 0)).astype(int).values


class EMACrossPatterns(Strategy):
    fast = 9
    slow = 21
    stop_pct = 0.010
    tp_pct = 0.015
    size = 50

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.fast = self.I(ema, self.data.Close, self.fast)
        self.slow = self.I(ema, self.data.Close, self.slow)
        self.bull = self.I(bullish_engulfing, self.data.Open, self.data.High, self.data.Low, self.data.Close)
        self.bear = self.I(bearish_engulfing, self.data.Open, self.data.High, self.data.Low, self.data.Close)
        self.hammer = self.I(hammer, self.data.Open, self.data.High, self.data.Low, self.data.Close)
        self.shoot = self.I(shooting_star, self.data.Open, self.data.High, self.data.Low, self.data.Close)

    def next(self):
        if self.position or len(self.fast) < 2:
            return
        price = self.data.Close[-1]
        cl = self.fast[-2] <= self.slow[-2] and self.fast[-1] > self.slow[-1]
        cs = self.fast[-2] >= self.slow[-2] and self.fast[-1] < self.slow[-1]
        bl = self.bull[-1] > 0 or self.hammer[-1] > 0
        br = self.bear[-1] > 0 or self.shoot[-1] > 0
        if cl and bl:
            self.buy(size=self.size, sl=price * (1 - self.stop_pct), tp=price * (1 + self.tp_pct))
        elif cs and br:
            self.sell(size=self.size, sl=price * (1 + self.stop_pct), tp=price * (1 - self.tp_pct))


def run(data):
    bt = Backtest(data, EMACrossPatterns, cash=1_000_000,
                  commission=0.0002, spread=0.0002, margin=0.1,
                  exclusive_orders=True, trade_on_close=False)
    return bt.run()


def walk_forward(data, n_windows=6):
    total = len(data)
    block_size = total // (n_windows + 1)
    out = []
    for k in range(n_windows):
        train_end = block_size * (k + 1)
        test_end = min(train_end + block_size, total)
        train = data.iloc[:train_end]
        test = data.iloc[train_end:test_end]
        if len(test) < 200:
            break
        s_train = run(train)
        s_test = run(test)
        out.append({
            "Окно": k + 1,
            "Test": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Train PF": round(s_train["Profit Factor"], 3) if not pd.isna(s_train["Profit Factor"]) else 0,
            "Test Trades": int(s_test["# Trades"]),
            "Test PF": round(s_test["Profit Factor"], 3) if not pd.isna(s_test["Profit Factor"]) else 0,
            "Test Sharpe": round(s_test["Sharpe Ratio"], 2) if not pd.isna(s_test["Sharpe Ratio"]) else 0,
            "Test Return%": round(s_test["Return [%]"], 3),
        })
    return pd.DataFrame(out)


if __name__ == "__main__":
    data = load_csv("ng_m1.csv")
    print("Баров: " + str(len(data)))
    print("")
    res = walk_forward(data, n_windows=6)
    print(res.to_string(index=False))
    if not res.empty:
        wins = (res["Test PF"] > 1.0).sum()
        print("")
        print("Окон с PF > 1.0: " + str(wins) + " из " + str(len(res)))
        print("Средний PF на OOS: " + str(round(res["Test PF"].mean(), 3)))
        print("Средний Sharpe на OOS: " + str(round(res["Test Sharpe"].mean(), 3)))