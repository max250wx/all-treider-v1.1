"""
AI-агент: анализ новостей через Ollama с учётом RVI.
Модель: qwen2.5:7b (или другая на выбор).
"""

import ollama
import pandas as pd
import os
import time

MODEL = "qwen2.5:7b"


def get_current_rvi():
    """Читает последнее значение RVI из rvi_data.csv."""
    if not os.path.exists("rvi_data.csv"):
        return None, None
    try:
        df = pd.read_csv("rvi_data.csv")
        if df.empty:
            return None, None
        last = df.iloc[-1]
        return float(last["rvi_current"]), float(last["change_pct"])
    except Exception:
        return None, None


def build_system_prompt(rvi, rvi_change):
    """Строит system-промпт с учётом RVI. Только русский язык."""

    if rvi is None:
        rvi_context = "RVI недоступен"
    else:
        if rvi > 60:
            rvi_context = "RVI=" + str(round(rvi, 2)) + " пунктов — ЭКСТРЕМАЛЬНАЯ ПАНИКА."
        elif rvi > 40:
            rvi_context = "RVI=" + str(round(rvi, 2)) + " пунктов — ПАНИКА."
        elif rvi < 20:
            rvi_context = "RVI=" + str(round(rvi, 2)) + " пунктов — СПОКОЙСТВИЕ."
        else:
            rvi_context = "RVI=" + str(round(rvi, 2)) + " пунктов — НЕЙТРАЛЬНО."

        if rvi_change is not None:
            direction = "растёт" if rvi_change > 0 else "падает"
            rvi_context += " Изменение за день: " + direction + " на " + str(round(abs(rvi_change), 2)) + "%."

    prompt = (
        "Ты — профессиональный трейдер российского рынка с 20-летним опытом.\n"
        "Специализация: санкции, геополитика, военные действия, действия ЦБ РФ.\n"
        "\n"
        "ТЕКУЩИЙ КОНТЕКСТ РЫНКА:\n"
        + rvi_context + "\n"
        "\n"
        "ВАЖНО ПРО RVI:\n"
        "RVI измеряется в ПУНКТАХ (например 30.03 или 45.21).\n"
        "НЕ В ПРОЦЕНТАХ. Не пиши «RVI не превышает 31.8%» — это ошибка.\n"
        "Проценты — это только change_pct (изменение за день).\n"
        "\n"
        "ПРИОРИТЕТ ФАКТОРОВ (важнее = выше):\n"
        "1. [GEO] Геополитика: санкции, военные действия, БПЛА, переговоры,\n"
        "    атаки на инфраструктуру, ограничения в аэропортах, Ближний Восток\n"
        "2. [CB] ЦБ РФ: ставка, риторика, интервенции\n"
        "3. [OIL] Цены на нефть/газ\n"
        "4. [CORP] Корпоративные новости (отчётности, сделки)\n"
        "5. [OTHER] Прочее\n"
        "\n"
        "ПРАВИЛА КЛАССИФИКАЦИИ:\n"
        "- Ограничения полётов, атаки БПЛА, обстрелы → [GEO], НЕ [OTHER]\n"
        "- Санкции, аресты активов, эмбарго → [GEO]\n"
        "- Заседания ЦБ, ставка, инфляция → [CB]\n"
        "- Цены на нефть, ОПЕК+, газ → [OIL]\n"
        "- Отчётности компаний, сделки M&A, дивиденды → [CORP]\n"
        "- Криминал, спорт, культура, быт → [OTHER]\n"
        "\n"
        "ПРАВИЛА ПРИНЯТИЯ РЕШЕНИЙ:\n"
        "\n"
        "LONG — если выполнено хотя бы одно:\n"
        "- Новость позитивна для российского рынка в целом\n"
        "- Новость напрямую улучшает положение эмитента\n"
        "- RVI < 20 или RVI падает более чем на 3%\n"
        "\n"
        "SHORT — если выполнено хотя бы одно:\n"
        "- Новость негативна для российского рынка\n"
        "- Новые санкции против крупных эмитентов\n"
        "- Эскалация военных действий\n"
        "- RVI > 40 или RVI растёт более чем на 5%\n"
        "\n"
        "NO TRADE — только если:\n"
        "- Новость криминальной, спортивной, культурной, бытовой тематики\n"
        "- Новость противоречива и не имеет чёткого направления\n"
        "\n"
        "ФОРМАТ ОТВЕТА (строго, на РУССКОМ языке):\n"
        "СИГНАЛ: LONG | SHORT | NO TRADE\n"
        "ПРИОРИТЕТ: [GEO/CB/OIL/CORP/OTHER]\n"
        "ОБОСНОВАНИЕ: 2-3 предложения с учётом RVI.\n"
        "\n"
        "ЗАПРЕЩЕНО:\n"
        "- Отказываться от анализа\n"
        "- Писать на английском или китайском\n"
        "- Использовать иероглифы\n"
        "- Писать дисклеймеры\n"
        "- Показывать рассуждения\n"
        "- Давать NO TRADE для всех новостей\n"
        "- Ошибаться в написании поля «ПРИОРИТЕТ»\n"
        "\n"
        "Только СИГНАЛ, ПРИОРИТЕТ, ОБОСНОВАНИЕ. Ничего больше."
    )
    return prompt

def analyze_news(title, rvi, rvi_change):
    """Отправляет новость в локальную модель, получает сигнал."""
    t0 = time.time()
    response = ollama.chat(
        model=MODEL,
        messages=[
            {"role": "system", "content": build_system_prompt(rvi, rvi_change)},
            {"role": "user", "content": "Новость: " + title},
        ],
        options={"temperature": 0.1, "num_predict": 300},
    )
    elapsed = time.time() - t0
    text = response["message"]["content"].strip()
    eval_count = response.get("eval_count", 0)
    eval_dur = response.get("eval_duration", 1) / 1e9
    speed = eval_count / eval_dur if eval_dur > 0 else 0
    return text + "\n\n[" + str(round(elapsed, 1)) + "s, " + str(int(speed)) + " ток/сек]"


if __name__ == "__main__":
    rvi, rvi_ch = get_current_rvi()
    if rvi is not None:
        print("Текущий RVI: " + str(round(rvi, 2)) + " (" + str(round(rvi_ch, 2)) + "%)")
    else:
        print("RVI не найден — анализ без контекста индекса страха")
    print()

    try:
        df = pd.read_csv("news_sentiment.csv")
    except FileNotFoundError:
        print("Файл news_sentiment.csv не найден")
        raise SystemExit

    # Топ-5 негативных + топ-3 позитивных
    neg = df.nsmallest(5, "sentiment")[["title", "sentiment"]]
    pos = df.nlargest(3, "sentiment")[["title", "sentiment"]]

    for label, subset in [("НЕГАТИВНЫЕ", neg), ("ПОЗИТИВНЫЕ", pos)]:
        print("#" * 70)
        print("# " + label)
        print("#" * 70)
        for _, row in subset.iterrows():
            print("-" * 70)
            print("Новость: " + str(row["title"])[:120])
            print("Sentiment: " + str(round(row["sentiment"], 3)))
            print("-" * 70)
            print(analyze_news(row["title"], rvi, rvi_ch))
            print()