"""Walk-forward чистой EMA Cross на длинной истории газа (ng_long.csv)."""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_csv(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={"open": "Open", "high": "High", "low": "Low",
                             "close": "Close", "volume": "Volume"})
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    return df[df["Volume"] > 0].sort_index()


class EMACross(Strategy):
    fast = 9
    slow = 21
    stop_pct = 0.010
    tp_pct = 0.015
    size = 50

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.fast = self.I(ema, self.data.Close, self.fast)
        self.slow = self.I(ema, self.data.Close, self.slow)

    def next(self):
        if self.position or len(self.fast) < 2:
            return
        price = self.data.Close[-1]
        if self.fast[-2] <= self.slow[-2] and self.fast[-1] > self.slow[-1]:
            self.buy(size=self.size,
                     sl=price * (1 - self.stop_pct),
                     tp=price * (1 + self.tp_pct))
        elif self.fast[-2] >= self.slow[-2] and self.fast[-1] < self.slow[-1]:
            self.sell(size=self.size,
                      sl=price * (1 + self.stop_pct),
                      tp=price * (1 - self.tp_pct))


def run(data):
    bt = Backtest(data, EMACross, cash=1_000_000,
                  commission=0.0002, spread=0.0002, margin=0.1,
                  exclusive_orders=True, trade_on_close=False)
    return bt.run()


def walk_forward(data, n_windows=8):
    total = len(data)
    block_size = total // (n_windows + 1)
    out = []
    for k in range(n_windows):
        train_end = block_size * (k + 1)
        test_end = min(train_end + block_size, total)
        train = data.iloc[:train_end]
        test = data.iloc[train_end:test_end]
        if len(test) < 500:
            break
        s_test = run(test)
        out.append({
            "Окно": k + 1,
            "Test период": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Trades": int(s_test["# Trades"]),
            "PF": round(s_test["Profit Factor"], 3) if not pd.isna(s_test["Profit Factor"]) else 0,
            "Sharpe": round(s_test["Sharpe Ratio"], 2) if not pd.isna(s_test["Sharpe Ratio"]) else 0,
            "Return%": round(s_test["Return [%]"], 3),
            "AvgTrade%": round(s_test["Avg. Trade [%]"], 4) if not pd.isna(s_test["Avg. Trade [%]"]) else 0,
        })
    return pd.DataFrame(out)


if __name__ == "__main__":
    data = load_csv("ng_long.csv")
    print("Баров: " + str(len(data)))
    print("Период: " + str(data.index[0]) + " — " + str(data.index[-1]))
    print("")

    # 1. Полный период — базовая оценка
    print("── Полный период (baseline) ──")
    s_full = run(data)
    print(pd.DataFrame([{
        "Trades": int(s_full["# Trades"]),
        "WinRate%": round(s_full["Win Rate [%]"], 2) if not pd.isna(s_full["Win Rate [%]"]) else 0,
        "PF": round(s_full["Profit Factor"], 3) if not pd.isna(s_full["Profit Factor"]) else 0,
        "Sharpe": round(s_full["Sharpe Ratio"], 2) if not pd.isna(s_full["Sharpe Ratio"]) else 0,
        "Return%": round(s_full["Return [%]"], 3),
        "MaxDD%": round(s_full["Max. Drawdown [%]"], 3),
    }]).to_string(index=False))
    print("")

    # 2. Walk-forward
    print("── Walk-forward (8 окон) ──")
    res = walk_forward(data, n_windows=8)
    print(res.to_string(index=False))

    if not res.empty:
        wins = (res["PF"] > 1.0).sum()
        print("")
        print("Окон с PF > 1.0: " + str(wins) + " из " + str(len(res)))
        print("Средний PF: " + str(round(res["PF"].mean(), 3)))
        print("Средний Sharpe: " + str(round(res["Sharpe"].mean(), 3)))
        print("Средний Return% на окно: " + str(round(res["Return%"].mean(), 3)))