"""
Watchdog v2: следит за всеми скриптами и тикерами робота.

Каждый тикер отслеживается отдельно.
Каждые N минут проверяется активность файлов. При зависании — перезапуск.
Плюс: раз в час обновляет новости и сентимент.
"""

import os
import sys
import time
import subprocess
from datetime import datetime


WORK_DIR = r"C:\trading"
LOG_FILE = os.path.join(WORK_DIR, "watchdog.log")
os.chdir(WORK_DIR)

STALL_MINUTES = 5
CHECK_INTERVAL_SEC = 60
NEWS_INTERVAL_MIN = 60    # раз в час обновлять новости


# ── Целевые процессы ──
TARGETS = [
    {
        "name": "orderflow_rest",
        "script": "orderflow_rest.py",
        "files": ["orderbook_GAZP.csv", "trades_GAZP.csv",
                  "orderbook_RUAL.csv", "trades_RUAL.csv"],
        "critical": True,
    },
    {
        "name": "rvi_collector",
        "script": "rvi_collector.py",
        "files": ["rvi_data.csv"],
        "critical": True,
    },
]


# ── Разовые задачи по расписанию ──
SCHEDULED = [
    {
        "name": "news_rss",
        "script": "news_rss.py",
        "interval_min": NEWS_INTERVAL_MIN,
    },
    {
        "name": "sentiment_ru",
        "script": "sentiment_ru.py",
        "interval_min": NEWS_INTERVAL_MIN,
    },
]


def log(msg):
    line = f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}"
    print(line)
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def get_mtime(path):
    full = os.path.join(WORK_DIR, path)
    if not os.path.exists(full):
        return 0
    return os.path.getmtime(full)


def last_activity(files):
    mtimes = [get_mtime(f) for f in files]
    return max(mtimes) if mtimes else 0


def launch(script):
    log(f"  → запуск: {script}")
    try:
        proc = subprocess.Popen(
            [sys.executable, script],
            cwd=WORK_DIR,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=(subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0),
        )
        return proc
    except Exception as e:
        log(f"  ОШИБКА запуска {script}: {e}")
        return None


def kill(proc):
    if proc is None or proc.poll() is not None:
        return
    try:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
    except Exception:
        pass


def run_once(script, timeout=600):
    """Запускает скрипт и ждёт завершения (для scheduled)."""
    log(f"  → scheduled: {script}")
    try:
        result = subprocess.run(
            [sys.executable, script],
            cwd=WORK_DIR,
            timeout=timeout,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        log(f"  ← {script} завершён с кодом {result.returncode}")
    except subprocess.TimeoutExpired:
        log(f"  ⏱ {script} — timeout {timeout}s")
    except Exception as e:
        log(f"  ОШИБКА {script}: {e}")


def main():
    log("=" * 70)
    log("WATCHDOG v2 стартовал")
    log("=" * 70)

    # Запускаем критичные процессы
    processes = {}
    for t in TARGETS:
        processes[t["name"]] = launch(t["script"])
        time.sleep(2)

    # Первый прогон scheduled
    scheduled_last = {}
    for s in SCHEDULED:
        run_once(s["script"])
        scheduled_last[s["name"]] = time.time()
    log("Новости и сентимент — первичный прогон завершён")

    last_seen = {t["name"]: time.time() for t in TARGETS}

    try:
        while True:
            time.sleep(CHECK_INTERVAL_SEC)
            now = time.time()

            # ── 1. Проверка тикеров/скриптов ──
            for t in TARGETS:
                name = t["name"]
                mtime = last_activity(t["files"])
                stall_sec = now - max(mtime, last_seen[name])
                stall_min = stall_sec / 60

                if stall_min >= STALL_MINUTES:
                    log(f"[!] {name}: нет активности {stall_min:.1f} мин — перезапуск")
                    kill(processes.get(name))
                    processes[name] = launch(t["script"])
                    last_seen[name] = now
                else:
                    log(f"[OK] {name}: активен {stall_min:.1f} мин назад")
                    last_seen[name] = now

            # ── 2. Scheduled задачи ──
            for s in SCHEDULED:
                elapsed_min = (now - scheduled_last[s["name"]]) / 60
                if elapsed_min >= s["interval_min"]:
                    run_once(s["script"])
                    scheduled_last[s["name"]] = now

    except KeyboardInterrupt:
        log("Watchdog остановлен")
        for name, proc in processes.items():
            kill(proc)


if __name__ == "__main__":
    main()