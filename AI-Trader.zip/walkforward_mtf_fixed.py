"""
Walk-forward MTF с 4 режимами фильтра — отдельными классами.
Проверяем, помогает ли HTF-фильтр или вредит.
"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_mtf(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={
        "open": "Open", "high": "High", "low": "Low",
        "close": "Close", "volume": "Volume",
    })
    return df


def atr(h, l, c, p):
    h, l, c = pd.Series(h), pd.Series(l), pd.Series(c)
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / p, adjust=False).mean()


class BaseMTF(Strategy):
    ema_period = 20
    atr_period = 14
    atr_entry = 2.0
    atr_stop = 1.5
    size = 500

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.ema = self.I(ema, self.data.Close, self.ema_period)
        self.atr = self.I(atr, self.data.High, self.data.Low,
                          self.data.Close, self.atr_period)
        self.d1 = self.data.D1Trend
        self.h4 = self.data.H4Trend
        self.h1 = self.data.H1Trend

    def _allow(self):
        raise NotImplementedError

    def next(self):
        if self.position:
            if self.position.is_long and self.data.Close[-1] >= self.ema[-1]:
                self.position.close()
            elif self.position.is_short and self.data.Close[-1] <= self.ema[-1]:
                self.position.close()
            return

        hour = self.data.index[-1].hour
        if not ((10 <= hour <= 11) or (14 <= hour <= 15)):
            return

        allow_long, allow_short = self._allow()
        if not (allow_long or allow_short):
            return

        if pd.isna(self.atr[-1]) or pd.isna(self.ema[-1]):
            return

        price = self.data.Close[-1]
        ema_v = self.ema[-1]
        a = self.atr[-1]

        if allow_long and price < ema_v - self.atr_entry * a:
            self.buy(size=self.size, sl=price - self.atr_stop * a, tp=ema_v)
        elif allow_short and price > ema_v + self.atr_entry * a:
            self.sell(size=self.size, sl=price + self.atr_stop * a, tp=ema_v)


class MTFStrict(BaseMTF):
    def _allow(self):
        d1, h4, h1 = int(self.d1[-1]), int(self.h4[-1]), int(self.h1[-1])
        return (d1 == 1 and h4 == 1 and h1 == 1,
                d1 == 0 and h4 == 0 and h1 == 0)


class MTF2of3(BaseMTF):
    def _allow(self):
        d1, h4, h1 = int(self.d1[-1]), int(self.h4[-1]), int(self.h1[-1])
        up = d1 + h4 + h1
        down = (1 - d1) + (1 - h4) + (1 - h1)
        return (up >= 2, down >= 2)


class MTFH4H1(BaseMTF):
    def _allow(self):
        h4, h1 = int(self.h4[-1]), int(self.h1[-1])
        return (h4 == 1 and h1 == 1,
                h4 == 0 and h1 == 0)


class MTFNoFilter(BaseMTF):
    def _allow(self):
        return (True, True)


def run(data, cls):
    bt = Backtest(data, cls, cash=1_000_000,
                  commission=0.0002, spread=0.0002, margin=0.1,
                  exclusive_orders=True, trade_on_close=False)
    return bt.run()


def walk_forward(data, cls, n_windows=5):
    total = len(data)
    block_size = total // (n_windows + 1)
    out = []
    for k in range(n_windows):
        test_end = block_size * (k + 2)
        test = data.iloc[block_size * (k + 1):test_end]
        if len(test) < 300:
            break
        s = run(test, cls)
        out.append({
            "Окно": k + 1,
            "Test": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Trades": int(s["# Trades"]),
            "WinRate%": round(s["Win Rate [%]"], 2) if not pd.isna(s["Win Rate [%]"]) else 0,
            "PF": round(s["Profit Factor"], 3) if not pd.isna(s["Profit Factor"]) else 0,
            "Sharpe": round(s["Sharpe Ratio"], 2) if not pd.isna(s["Sharpe Ratio"]) else 0,
            "Return%": round(s["Return [%]"], 3),
        })
    return pd.DataFrame(out)


if __name__ == "__main__":
    data = load_mtf("ngu6_mtf.csv")
    print("NGU6, баров:", len(data))
    print("")

    for name, cls in [
        ("strict (D1=H4=H1)", MTFStrict),
        ("2of3 (>=2 из 3)",   MTF2of3),
        ("h4h1 (H4=H1)",      MTFH4H1),
        ("NO FILTER",         MTFNoFilter),
    ]:
        print("=" * 95)
        print("  Режим: " + name)
        print("=" * 95)

        s = run(data, cls)
        print("── Полный период ──")
        print(pd.DataFrame([{
            "Trades": int(s["# Trades"]),
            "WinRate%": round(s["Win Rate [%]"], 2) if not pd.isna(s["Win Rate [%]"]) else 0,
            "PF": round(s["Profit Factor"], 3) if not pd.isna(s["Profit Factor"]) else 0,
            "Sharpe": round(s["Sharpe Ratio"], 2) if not pd.isna(s["Sharpe Ratio"]) else 0,
            "Return%": round(s["Return [%]"], 3),
            "MaxDD%": round(s["Max. Drawdown [%]"], 3),
        }]).to_string(index=False))

        res = walk_forward(data, cls, n_windows=5)
        print("")
        print("── Walk-forward ──")
        print(res.to_string(index=False))
        if not res.empty:
            wins = (res["PF"] > 1.0).sum()
            nonempty = (res["Trades"] > 0).sum()
            print("Окон PF>1: " + str(wins) + " из " + str(len(res)) + ", со сделками: " + str(nonempty) + " из " + str(len(res)))
        print("")