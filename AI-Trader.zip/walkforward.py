"""
Walk-forward анализ EMA Cross на BR и NG.
Скользящее окно: train расширяется, test идёт следом.
"""

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from backtesting import Backtest, Strategy


def load_csv(path):
    df = pd.read_csv(path, parse_dates=True, index_col=0)
    df = df.rename(columns={
        "open": "Open", "high": "High", "low": "Low",
        "close": "Close", "volume": "Volume",
    })
    df = df[["Open", "High", "Low", "Close", "Volume"]].dropna()
    df = df[df["Volume"] > 0].sort_index()
    return df


class EMACross(Strategy):
    fast = 9
    slow = 21
    stop_pct = 0.010
    tp_pct = 0.015
    size = 50

    def init(self):
        def ema(s, p):
            return pd.Series(s).ewm(span=p, adjust=False).mean()
        self.fast = self.I(ema, self.data.Close, self.fast)
        self.slow = self.I(ema, self.data.Close, self.slow)

    def next(self):
        if self.position or len(self.fast) < 2:
            return
        price = self.data.Close[-1]
        if self.fast[-2] <= self.slow[-2] and self.fast[-1] > self.slow[-1]:
            self.buy(size=self.size,
                     sl=price * (1 - self.stop_pct),
                     tp=price * (1 + self.tp_pct))
        elif self.fast[-2] >= self.slow[-2] and self.fast[-1] < self.slow[-1]:
            self.sell(size=self.size,
                      sl=price * (1 + self.stop_pct),
                      tp=price * (1 - self.tp_pct))


def run(data, fast, slow):
    bt = Backtest(
        data, EMACross,
        cash=1_000_000,
        commission=0.0002,
        spread=0.0002,
        margin=0.1,
        exclusive_orders=True,
        trade_on_close=False,
    )
    return bt.run(fast=fast, slow=slow)


def walk_forward(data, n_windows=4):
    total = len(data)
    block_size = total // (n_windows + 1)
    params_grid = [(5, 21), (9, 21), (12, 26), (15, 40), (5, 40), (8, 30)]

    out = []
    for k in range(n_windows):
        train_end = block_size * (k + 1)
        test_end = train_end + block_size
        if test_end > total:
            break

        train = data.iloc[:train_end]
        test = data.iloc[train_end:test_end]

        if len(train) < 500 or len(test) < 200:
            continue

        best = None
        for fast, slow in params_grid:
            s = run(train, fast, slow)
            sharpe = s["Sharpe Ratio"]
            if pd.isna(sharpe) or sharpe == np.inf:
                continue
            if best is None or sharpe > best["sharpe"]:
                best = {"fast": fast, "slow": slow, "sharpe": sharpe}

        if best is None:
            continue

        s_test = run(test, best["fast"], best["slow"])

        out.append({
            "Окно": k + 1,
            "Train до": str(train.index[-1].date()),
            "Test": str(test.index[0].date()) + "…" + str(test.index[-1].date()),
            "Best": str(best["fast"]) + "/" + str(best["slow"]),
            "Train Sharpe": round(best["sharpe"], 2),
            "Test Trades": int(s_test["# Trades"]),
            "Test PF": round(s_test["Profit Factor"], 3) if not pd.isna(s_test["Profit Factor"]) else 0,
            "Test Sharpe": round(s_test["Sharpe Ratio"], 2) if not pd.isna(s_test["Sharpe Ratio"]) else 0,
            "Test Return%": round(s_test["Return [%]"], 3),
        })

    return pd.DataFrame(out)


if __name__ == "__main__":
    for name, file in [("BR (Brent)", "br_m1.csv"), ("NG (Gas)", "ng_m1.csv")]:
        print("")
        print("=" * 95)
        print("  WALK-FORWARD: " + name)
        print("=" * 95)
        data = load_csv(file)
        print("Всего баров: " + str(len(data)))
        print("Период: " + str(data.index[0]) + " — " + str(data.index[-1]))
        print("")

        results = walk_forward(data, n_windows=4)

        if results.empty:
            print("Walk-forward не дал результатов (слишком короткие окна)")
            continue

        print(results.to_string(index=False))

        oos_pf = results["Test PF"]
        wins = (oos_pf > 1.0).sum()
        print("")
        print("Окон с PF > 1.0 на OOS: " + str(wins) + " из " + str(len(results)))
        print("Средний PF на OOS: " + str(round(oos_pf.mean(), 3)))
        print("Средний Sharpe на OOS: " + str(round(results["Test Sharpe"].mean(), 3)))