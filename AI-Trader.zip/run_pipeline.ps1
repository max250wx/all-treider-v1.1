# run_pipeline.ps1
# Последовательно запускает весь пайплайн:
# 1. Сбор новостей
# 2. Анализ сентимента
# 3. Сбор потока ордеров (N секунд)
# 4. Объединение данных
#
# Запуск: powershell -ExecutionPolicy Bypass -File run_pipeline.ps1

$ErrorActionPreference = "Stop"

# ── НАСТРОЙКИ ──
$WORK_DIR = "C:\trading"
$COLLECT_SECONDS = 1800   # сколько секунд собирать поток ордеров (30 минут)

Set-Location $WORK_DIR

Write-Host "===============================================" -ForegroundColor Cyan
Write-Host "  T-Invest Pipeline" -ForegroundColor Cyan
Write-Host "  Старт: $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Cyan

# ── 1. Сбор новостей ──
Write-Host "`n[1/4] Сбор новостей..." -ForegroundColor Yellow
python news_rss.py

# ── 2. Анализ сентимента ──
Write-Host "`n[2/4] Анализ сентимента..." -ForegroundColor Yellow
python sentiment_ru.py

# ── 3. Сбор потока ордеров ──
Write-Host "`n[3/4] Сбор потока ордеров ($COLLECT_SECONDS секунд)..." -ForegroundColor Yellow
$collector = Start-Process -FilePath "python" -ArgumentList "orderflow_collector.py" -PassThru -NoNewWindow

Write-Host "  Ждём $COLLECT_SECONDS секунд..."
Start-Sleep -Seconds $COLLECT_SECONDS

Write-Host "  Останавливаем сборщик..." -ForegroundColor Yellow
Stop-Process -Id $collector.Id -Force
Start-Sleep -Seconds 2

# ── 4. Объединение данных ──
Write-Host "`n[4/4] Объединение данных..." -ForegroundColor Yellow
python merge_pipeline.py

Write-Host "`n===============================================" -ForegroundColor Green
Write-Host "  Готово: $(Get-Date -Format 'HH:mm:ss')" -ForegroundColor Green
Write-Host "===============================================" -ForegroundColor Green